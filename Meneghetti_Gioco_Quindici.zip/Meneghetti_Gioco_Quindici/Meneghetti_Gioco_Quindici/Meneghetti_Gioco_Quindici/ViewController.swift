//
//  ViewController.swift
//  Meneghetti_Gioco_Quindici
//
//  Created by MATTEO MENEGHETTI on 23/10/2019.
//  Copyright © 2019 MATTEO MENEGHETTI. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var buttonEmpty: UIButton!
    
    var numeri = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
    var arr : [[Int]] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func random(){
        var i = 3
        var j = 3
        arr[3][3] = 0;
        let generatore = arc4random_uniform(55)
        for _ in 0...generatore{
            if (generatore % 2 == 0){
                if(i<0){
                    i+=2
                    arr[i][j] = arr[i+1][j]
                }
                i-=1
                arr[i][j] = arr[i+1][j]
            }
            else{
                if(j<0){
                    
                }
                j-=1
                arr[i][j] = arr[i][j+1]
            }
        }
        
    }
    @IBAction func btn_1(_ sender: UIButton)
    {
        
    }
    
    @IBAction func btn_14(_ sender: UIButton) {
        if(buttonEmpty.titleLabel == nil){
            
        }
    }
    
}

